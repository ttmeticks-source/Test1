#!/usr/bin/env python3
"""Black Hat — privacy-first PyQt6 browser for macOS.

Features:
- Chromium traffic is configured to use a local Tor SOCKS5 proxy.
- Off-the-record QWebEngineProfile (memory-only cookies/cache/history).
- HTTPS-only navigation and request blocking.
- EasyList/EasyPrivacy domain rule import (domain-level rules only).
- Local persistent denylist for security-blocked hosts.
- Downloads go to a private /tmp quarantine directory; SHA-256 is calculated.
- Optional VirusTotal hash lookup is made through Tor only (set VT_API_KEY).
- Fingerprinting surface is reduced with a small, stable DocumentCreation script.
- Network/security console and Tor status display.

This is a practical privacy tool, not a guarantee of anonymity or malware detection.
A VirusTotal "not found" result means unknown, not clean. No file is run automatically.
"""

# IMPORTANT: these flags must be set before QApplication / QtWebEngine starts.
import os
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
    "--proxy-server=socks5://127.0.0.1:9050 "
    "--proxy-bypass-list=<-loopback> "
    "--webrtc-ip-handling-policy=disable_non_proxied_udp "
    "--disable-webrtc"
)

import hashlib
import html
import json
import re
import shutil
import socket
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import quote_plus, urlsplit

try:
    import requests
except Exception:
    requests = None

from PyQt6.QtCore import Qt, QUrl, QTimer, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QAction, QFont, QKeySequence
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QLabel, QTextEdit, QSplitter, QFrame,
    QMessageBox, QFileDialog, QToolButton, QSizePolicy
)
from PyQt6.QtWebEngineCore import (
    QWebEngineProfile, QWebEngineUrlRequestInterceptor, QWebEnginePage,
    QWebEngineSettings, QWebEngineScript, QWebEngineDownloadRequest
)
from PyQt6.QtWebEngineWidgets import QWebEngineView


APP_NAME = "Black Hat"
TOR_SOCKS_HOST = "127.0.0.1"
TOR_SOCKS_PORT = 9050
TOR_CONTROL_HOST = "127.0.0.1"
TOR_CONTROL_PORT = 9051
TOR_PROXIES = {
    "http": f"socks5h://{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}",
    "https": f"socks5h://{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}",
}

APP_SUPPORT = Path.home() / "Library" / "Application Support" / "BlackHat"
BLOCKLIST_FILE = APP_SUPPORT / "blocked_hosts.json"
QUARANTINE_DIR = Path(tempfile.gettempdir()) / f"blackhat-quarantine-{os.getuid()}"

# Small offline baseline. Full domain-level rules are fetched from EasyList/EasyPrivacy
# only when the Tor SOCKS proxy is reachable.
BUILTIN_BLOCKED_DOMAINS = {
    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "googletagmanager.com", "google-analytics.com", "analytics.google.com",
    "adservice.google.com", "adnxs.com", "adsrvr.org", " serving-sys.com".strip(),
    "criteo.com", "criteo.net", "scorecardresearch.com", "quantserve.com",
    "hotjar.com", "segment.io", "segment.com", "mixpanel.com", "newrelic.com",
    "amplitude.com", "branch.io", "taboola.com", "outbrain.com",
    "adform.net", "rubiconproject.com", "pubmatic.com", "openx.net",
    "smartadserver.com", "adroll.com", "pixel.facebook.com", "connect.facebook.net",
}

FILTER_URLS = (
    "https://raw.githubusercontent.com/easylist/easylist/master/easylist/easylist_general_block.txt",
    "https://raw.githubusercontent.com/easylist/easylist/master/easyprivacy/easyprivacy_trackingservers.txt",
    "https://raw.githubusercontent.com/easylist/easylist/master/easyprivacy/easyprivacy_general.txt",
)

HOME_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Black Hat</title>
<style>
:root{color-scheme:dark;--bg:#090d0c;--panel:#101816;--line:#20352d;--green:#00ff9d;--muted:#93a69e;--white:#e9f4ef}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 50% 34%,#123126 0%,#0a100e 43%,#070909 100%);color:var(--white);font:15px -apple-system,BlinkMacSystemFont,"SF Pro Display",sans-serif;display:grid;place-items:center}
main{width:min(760px,92vw);text-align:center;padding:56px 22px 76px}.mark{display:inline-grid;place-items:center;width:68px;height:68px;border:1px solid #1c6d4d;border-radius:19px;color:var(--green);font:bold 25px ui-monospace,monospace;box-shadow:0 0 38px #00ff9d20;background:#0d1b15}
h1{font-size:clamp(39px,7vw,68px);letter-spacing:.12em;margin:22px 0 7px;font-weight:800}h1 span{color:var(--green)}.sub{color:var(--muted);letter-spacing:.16em;text-transform:uppercase;font-size:11px;margin-bottom:38px}
form{display:flex;gap:10px;padding:8px;background:#0c1411;border:1px solid #24533f;border-radius:15px;box-shadow:0 12px 60px #0008}input{flex:1;min-width:0;background:transparent;border:0;outline:0;color:white;padding:12px 14px;font-size:16px}button{border:0;border-radius:10px;background:var(--green);color:#04150d;padding:0 23px;font-weight:800;cursor:pointer}button:hover{filter:brightness(1.12)}.tiles{display:flex;flex-wrap:wrap;justify-content:center;gap:10px;margin-top:23px}.tiles a{color:#b8d5c8;text-decoration:none;padding:10px 14px;border:1px solid var(--line);border-radius:9px;background:#0c1411}.tiles a:hover{border-color:var(--green);color:var(--green)}.note{margin-top:43px;color:#64786f;font:11px ui-monospace,monospace;line-height:1.8}
</style></head><body><main><div class="mark">BH</div><h1>BLACK <span>HAT</span></h1><div class="sub">Private browsing · Tracker defense · Tor route</div>
<form onsubmit="event.preventDefault();const q=document.getElementById('q').value.trim();if(q)location.href='https://www.google.com/search?q='+encodeURIComponent(q)"><input id="q" autofocus autocomplete="off" placeholder="Search the web or enter an address"><button type="submit">SEARCH</button></form>
<div class="tiles"><a href="https://www.wikipedia.org/">Wikipedia</a><a href="https://www.mozilla.org/">Mozilla</a><a href="https://www.eff.org/">EFF</a><a href="https://check.torproject.org/">Tor Check</a></div>
<div class="note">NO LOCAL BROWSING HISTORY · MEMORY-ONLY SESSION<br>Traffic requires Tor running on 127.0.0.1:9050 · HTTPS ONLY</div></main></body></html>"""


def safe_filename(name: str) -> str:
    name = Path(name or "download.bin").name
    name = re.sub(r"[^A-Za-z0-9._ -]", "_", name).strip(" .")
    return (name[:120] or "download.bin")


def host_matches(host: str, domains) -> bool:
    """Fast exact/suffix lookup for a host against a set of blocked domains."""
    host = (host or "").lower().strip(".")
    if not host:
        return False
    if host in domains:
        return True
    labels = host.split(".")
    return any(".".join(labels[i:]) in domains for i in range(1, len(labels) - 1))


def read_blocklist() -> set[str]:
    try:
        data = json.loads(BLOCKLIST_FILE.read_text(encoding="utf-8"))
        return {str(x).lower().strip(".") for x in data if isinstance(x, str) and x.strip()}
    except Exception:
        return set()


def write_blocklist(domains: set[str]) -> None:
    APP_SUPPORT.mkdir(parents=True, exist_ok=True)
    tmp = BLOCKLIST_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(sorted(domains), indent=2), encoding="utf-8")
    os.replace(tmp, BLOCKLIST_FILE)


def tor_socks_available(timeout: float = 0.7) -> bool:
    try:
        with socket.create_connection((TOR_SOCKS_HOST, TOR_SOCKS_PORT), timeout=timeout):
            return True
    except OSError:
        return False


def parse_filter_domains(text: str) -> set[str]:
    """Extract simple hostname rules from ABP filter lists; skip cosmetic/path rules."""
    found = set()
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith(("!", "[", "@@")):
            continue
        if line.startswith("||"):
            # Only ingest complete domain rules; path-specific rules would otherwise
            # incorrectly block every URL on that host.
            match = re.fullmatch(r"\|\|([a-z0-9.-]+)\^(?:\$[^\s]*)?", line, flags=re.IGNORECASE)
            if match:
                token = match.group(1).lower().strip(".")
                if "." in token:
                    found.add(token)
        elif line.startswith("0.0.0.0 ") or line.startswith("127.0.0.1 "):
            parts = line.split()
            if len(parts) > 1:
                token = parts[1].lower().strip(".")
                if re.fullmatch(r"[a-z0-9.-]+", token) and "." in token:
                    found.add(token)
    return found


class FilterListWorker(QThread):
    completed = pyqtSignal(object, str)

    def run(self):
        if requests is None:
            self.completed.emit(set(), "requests is not installed; using built-in filters")
            return
        if not tor_socks_available():
            self.completed.emit(set(), "Tor SOCKS proxy unavailable; using built-in filters")
            return
        domains = set()
        errors = 0
        for url in FILTER_URLS:
            try:
                response = requests.get(url, proxies=TOR_PROXIES, timeout=5, headers={"User-Agent": "BlackHat/1.0 filter updater"})
                response.raise_for_status()
                domains.update(parse_filter_domains(response.text))
            except Exception:
                errors += 1
        note = f"Loaded {len(domains):,} domain rules from EasyList/EasyPrivacy" if domains else "Could not refresh filter lists; using built-in filters"
        if errors:
            note += f" ({errors} source(s) unavailable)"
        self.completed.emit(domains, note)


class IpCheckWorker(QThread):
    completed = pyqtSignal(str, str)

    def run(self):
        if requests is None:
            self.completed.emit("—", "requests module missing")
            return
        try:
            response = requests.get(
                "https://check.torproject.org/api/ip",
                proxies=TOR_PROXIES,
                timeout=8,
                headers={"User-Agent": "BlackHat/1.0"},
            )
            response.raise_for_status()
            data = response.json()
            if data.get("IsTor") is True:
                ip = str(data.get("IP", "—"))
                bits = ip.split(".")
                masked = ".".join(bits[:2] + ["***", "***"]) if len(bits) == 4 else "Tor verified"
                self.completed.emit(masked, "Tor exit verified")
            else:
                self.completed.emit("—", "Proxy responded, but Tor was not verified")
        except Exception as exc:
            self.completed.emit("—", f"Tor IP check unavailable: {type(exc).__name__}")


class TorControlWorker(QThread):
    completed = pyqtSignal(bool, str)

    def _read_reply(self, stream):
        lines = []
        while True:
            line = stream.readline()
            if not line:
                break
            lines.append(line)
            if len(line) >= 4 and line[3:4] == b" ":
                break
        return b"".join(lines)

    def run(self):
        try:
            with socket.create_connection((TOR_CONTROL_HOST, TOR_CONTROL_PORT), timeout=2.5) as sock:
                stream = sock.makefile("rwb", buffering=0)
                stream.write(b"PROTOCOLINFO 1\r\n")
                protocol = self._read_reply(stream).decode("utf-8", "replace")
                match = re.search(r'COOKIEFILE="([^"]+)"', protocol)
                if not match:
                    self.completed.emit(False, "Tor ControlPort has no COOKIEFILE; enable CookieAuthentication")
                    return
                cookie_path = Path(match.group(1))
                cookie = cookie_path.read_bytes()
                stream.write(f"AUTHENTICATE {cookie.hex()}\r\n".encode("ascii"))
                auth = self._read_reply(stream)
                if not auth.startswith(b"250"):
                    self.completed.emit(False, "Tor control authentication failed")
                    return
                stream.write(b"SIGNAL NEWNYM\r\n")
                reply = self._read_reply(stream)
                stream.write(b"QUIT\r\n")
                if reply.startswith(b"250"):
                    self.completed.emit(True, "Tor accepted NEWNYM; new circuits may take a few seconds")
                else:
                    self.completed.emit(False, reply.decode("utf-8", "replace").strip() or "Tor did not accept NEWNYM")
        except Exception as exc:
            self.completed.emit(False, f"Tor ControlPort unavailable: {type(exc).__name__}")


class FileScanWorker(QThread):
    completed = pyqtSignal(str, str, str, str, str)

    def __init__(self, file_path: str, source_url: str, api_key: str, parent=None):
        super().__init__(parent)
        self.file_path = file_path
        self.source_url = source_url
        self.api_key = api_key

    def run(self):
        sha256 = ""
        try:
            digest = hashlib.sha256()
            with open(self.file_path, "rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
            sha256 = digest.hexdigest()
        except Exception as exc:
            self.completed.emit(self.file_path, self.source_url, "", "error", f"Hash failed: {type(exc).__name__}")
            return

        if not self.api_key:
            self.completed.emit(self.file_path, self.source_url, sha256, "unknown", "SHA-256 calculated; set VT_API_KEY to enable VirusTotal hash checks")
            return
        if requests is None:
            self.completed.emit(self.file_path, self.source_url, sha256, "unknown", "requests is unavailable; file remains quarantined")
            return
        if not tor_socks_available():
            self.completed.emit(self.file_path, self.source_url, sha256, "unknown", "Tor proxy unavailable; no direct API request was made")
            return

        try:
            response = requests.get(
                f"https://www.virustotal.com/api/v3/files/{sha256}",
                headers={"x-apikey": self.api_key, "accept": "application/json"},
                proxies=TOR_PROXIES,
                timeout=12,
            )
            if response.status_code == 404:
                self.completed.emit(self.file_path, self.source_url, sha256, "unknown", "VirusTotal has no report for this hash; unknown is not the same as clean")
                return
            response.raise_for_status()
            stats = response.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            malicious = int(stats.get("malicious", 0))
            suspicious = int(stats.get("suspicious", 0))
            if malicious > 0:
                self.completed.emit(self.file_path, self.source_url, sha256, "malicious", f"VirusTotal reports {malicious} malicious detection(s)")
            elif suspicious > 0:
                self.completed.emit(self.file_path, self.source_url, sha256, "review", f"VirusTotal reports {suspicious} suspicious detection(s); manual review required")
            else:
                self.completed.emit(self.file_path, self.source_url, sha256, "clean", "No malicious or suspicious detections in the available VirusTotal report")
        except Exception as exc:
            self.completed.emit(self.file_path, self.source_url, sha256, "unknown", f"VirusTotal lookup failed: {type(exc).__name__}; file remains quarantined")


class RequestInterceptor(QWebEngineUrlRequestInterceptor):
    event = pyqtSignal(str, str)
    blocked = pyqtSignal(str, str)

    def __init__(self, tracker_domains: set[str], security_domains: set[str], parent=None):
        super().__init__(parent)
        self.tracker_domains = tracker_domains
        self.security_domains = security_domains

    def update_domains(self, tracker_domains: set[str], security_domains: set[str]):
        self.tracker_domains = set(tracker_domains)
        self.security_domains = set(security_domains)

    def interceptRequest(self, info):  # Qt virtual override
        url = info.requestUrl()
        scheme = url.scheme().lower()
        host = url.host().lower().strip(".")
        full = url.toString()
        if scheme == "http":
            info.block(True)
            self.blocked.emit(host or full, "HTTP blocked (HTTPS-only)")
            return
        if scheme not in ("https", "wss", "data", "about", "blob", "qrc"):
            if scheme:
                info.block(True)
                self.blocked.emit(host or scheme, f"Blocked scheme: {scheme}")
            return
        if host_matches(host, self.security_domains):
            info.block(True)
            self.blocked.emit(host, "Security denylist")
            return
        if host_matches(host, self.tracker_domains):
            info.block(True)
            self.blocked.emit(host, "Ad/tracker filter")
            return
        if scheme in ("https", "wss") and host:
            self.event.emit(host, "REQUEST")


class BrowserPage(QWebEnginePage):
    def __init__(self, profile, owner, parent=None):
        super().__init__(profile, parent)
        self.owner = owner

    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        scheme = url.scheme().lower()
        host = url.host().lower().strip(".")
        if scheme == "http":
            self.owner.log_event(host or url.toString(), "BLOCKED · HTTPS-only navigation")
            if is_main_frame:
                QTimer.singleShot(0, lambda u=url.toString(): self.owner.show_message_page(
                    "HTTPS REQUIRED", "This browser blocks unencrypted HTTP connections.",
                    f"The requested address was: {u}"
                ))
            return False
        if scheme in ("https", "about", "data", "blob", "qrc"):
            if scheme == "https" and host_matches(host, self.owner.security_domains):
                self.owner.log_event(host, "BLOCKED · security denylist")
                if is_main_frame:
                    QTimer.singleShot(0, lambda h=host: self.owner.show_threat_page(h, "This host is on the local security blocklist."))
                return False
            if scheme == "https" and not self.owner.tor_verified:
                self.owner.log_event(host or url.toString(), "BLOCKED · Tor exit not verified")
                if is_main_frame:
                    QTimer.singleShot(0, lambda: self.owner.show_message_page("TOR NOT VERIFIED", "Black Hat will not browse until the proxy is verified as a Tor exit.", "Start Tor and wait for TOR: VERIFIED in the status bar."))
                return False
            return True
        self.owner.log_event(host or scheme or "unknown", f"BLOCKED · unsupported scheme {scheme}")
        return False


class BrowserWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Black Hat — Private Browser")
        self.resize(1440, 900)
        self.setMinimumSize(900, 620)

        self.tor_online = False
        self.tor_verified = False
        self.blocked_count = 0
        self.tracker_domains = set(BUILTIN_BLOCKED_DOMAINS)
        self.security_domains = read_blocklist()
        self.filter_worker = None
        self.ip_worker = None
        self.control_worker = None
        self.scan_workers = []
        self.pending_sources = {}
        self.current_downloads = set()
        self._make_ui()
        self._new_profile_and_page()
        self._install_shortcuts()
        self._show_home()
        self._check_timer = QTimer(self)
        self._check_timer.timeout.connect(self.check_tor_status)
        self._check_timer.start(5000)
        QTimer.singleShot(250, self.check_tor_status)
        QTimer.singleShot(900, self.refresh_filter_lists)
        self.log_event("SYSTEM", "Black Hat initialized · off-the-record profile requested")
        self.log_event("POLICY", "HTTPS-only · WebRTC disabled · downloads quarantined")
        self.log_event("PRIVACY", "No browsing history, cookies, or HTTP cache are persisted by this profile")

    def _make_ui(self):
        root = QWidget()
        root.setObjectName("root")
        main = QVBoxLayout(root)
        main.setContentsMargins(0, 0, 0, 0)
        main.setSpacing(0)

        top = QFrame()
        top.setObjectName("toolbar")
        top_layout = QHBoxLayout(top)
        top_layout.setContentsMargins(16, 13, 16, 13)
        top_layout.setSpacing(8)

        brand = QLabel("◈ BLACK HAT")
        brand.setObjectName("brand")
        brand.setMinimumWidth(142)
        top_layout.addWidget(brand)

        self.back_btn = self._tool_button("‹", "Back", self.go_back)
        self.forward_btn = self._tool_button("›", "Forward", self.go_forward)
        self.reload_btn = self._tool_button("↻", "Reload", self.reload_page)
        self.home_btn = self._tool_button("⌂", "Home", self._show_home)
        for button in (self.back_btn, self.forward_btn, self.reload_btn, self.home_btn):
            top_layout.addWidget(button)

        self.address = QLineEdit()
        self.address.setObjectName("address")
        self.address.setPlaceholderText("Search securely or enter an HTTPS address")
        self.address.returnPressed.connect(self.navigate)
        top_layout.addWidget(self.address, 1)

        go = QPushButton("GO")
        go.setObjectName("goButton")
        go.clicked.connect(self.navigate)
        top_layout.addWidget(go)

        self.console_toggle = QPushButton("CONSOLE")
        self.console_toggle.setObjectName("secondaryButton")
        self.console_toggle.clicked.connect(self.toggle_console)
        top_layout.addWidget(self.console_toggle)

        self.reset_btn = QPushButton("RESET SESSION")
        self.reset_btn.setObjectName("burnButton")
        self.reset_btn.setToolTip("Clear in-memory browser state and request a fresh Tor circuit")
        self.reset_btn.clicked.connect(self.reset_session)
        top_layout.addWidget(self.reset_btn)

        main.addWidget(top)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.browser = QWebEngineView()
        self.browser.setObjectName("browser")
        self.browser.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.browser.urlChanged.connect(self.on_url_changed)
        self.browser.loadStarted.connect(lambda: self.log_event("BROWSER", "Navigation started"))
        self.browser.loadFinished.connect(self.on_load_finished)
        self.browser.titleChanged.connect(self.on_title_changed)
        self.splitter.addWidget(self.browser)

        self.console_panel = QFrame()
        self.console_panel.setObjectName("consolePanel")
        console_layout = QVBoxLayout(self.console_panel)
        console_layout.setContentsMargins(10, 10, 10, 10)
        console_title = QLabel("LIVE NETWORK INSPECTOR  //  EVENTS")
        console_title.setObjectName("consoleTitle")
        console_layout.addWidget(console_title)
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setObjectName("console")
        self.console.setFont(QFont("Menlo", 10))
        self.console.document().setMaximumBlockCount(1200)
        console_layout.addWidget(self.console, 1)
        self.clear_console_btn = QPushButton("CLEAR CONSOLE")
        self.clear_console_btn.setObjectName("secondaryButton")
        self.clear_console_btn.clicked.connect(self.console.clear)
        console_layout.addWidget(self.clear_console_btn)
        self.console_panel.setMinimumWidth(280)
        self.console_panel.setMaximumWidth(460)
        self.splitter.addWidget(self.console_panel)
        self.splitter.setSizes([1050, 350])
        main.addWidget(self.splitter, 1)

        status = QFrame()
        status.setObjectName("statusbar")
        status_layout = QHBoxLayout(status)
        status_layout.setContentsMargins(16, 8, 16, 8)
        self.tor_label = QLabel("TOR: CHECKING")
        self.tor_label.setObjectName("statusDim")
        self.ip_label = QLabel("EXIT IP: —")
        self.ip_label.setObjectName("statusDim")
        self.https_label = QLabel("HTTPS-ONLY")
        self.https_label.setObjectName("statusGood")
        self.blocked_label = QLabel("BLOCKED: 0")
        self.blocked_label.setObjectName("statusAccent")
        status_layout.addWidget(self.tor_label)
        status_layout.addWidget(self._separator_label())
        status_layout.addWidget(self.ip_label)
        status_layout.addStretch(1)
        status_layout.addWidget(self.https_label)
        status_layout.addWidget(self._separator_label())
        status_layout.addWidget(self.blocked_label)
        main.addWidget(status)

        self.setCentralWidget(root)
        self._apply_style()

    def _tool_button(self, text, tooltip, callback):
        button = QToolButton()
        button.setText(text)
        button.setToolTip(tooltip)
        button.setObjectName("navButton")
        button.setFixedSize(34, 34)
        button.clicked.connect(callback)
        return button

    def _separator_label(self):
        label = QLabel("│")
        label.setObjectName("separator")
        return label

    def _apply_style(self):
        self.setStyleSheet("""
            QWidget#root { background:#080c0b; color:#e6f0eb; }
            QFrame#toolbar { background:#101715; border-bottom:1px solid #20352d; }
            QLabel#brand { color:#00ff9d; font-size:15px; font-weight:900; letter-spacing:2px; }
            QToolButton#navButton { background:#18211e; border:1px solid #263b32; color:#c6d8cf; border-radius:8px; font-size:19px; }
            QToolButton#navButton:hover { border-color:#00ff9d; color:#00ff9d; }
            QLineEdit#address { background:#090f0c; border:1px solid #2a4c3c; border-radius:9px; padding:9px 13px; color:#f0fff7; selection-background-color:#006a43; font-size:13px; }
            QLineEdit#address:focus { border:1px solid #00ff9d; }
            QPushButton#goButton { background:#00ff9d; color:#06140d; border:0; border-radius:8px; padding:9px 17px; font-weight:900; }
            QPushButton#secondaryButton { background:#17231e; color:#b7cec2; border:1px solid #294337; border-radius:8px; padding:8px 12px; font-size:10px; font-weight:800; }
            QPushButton#secondaryButton:hover { border-color:#00ff9d; color:#00ff9d; }
            QPushButton#burnButton { background:#a82435; color:#fff; border:1px solid #df485a; border-radius:8px; padding:9px 13px; font-size:10px; font-weight:900; }
            QPushButton#burnButton:hover { background:#c72e43; }
            QFrame#consolePanel { background:#090f0c; border-left:1px solid #20352d; }
            QLabel#consoleTitle { color:#00ff9d; font: bold 10px Menlo,monospace; letter-spacing:1px; }
            QTextEdit#console { background:#070b09; border:1px solid #1d3229; border-radius:7px; color:#9ad9b8; padding:8px; }
            QFrame#statusbar { background:#101715; border-top:1px solid #20352d; }
            QLabel#statusDim { color:#9aada4; font:10px Menlo,monospace; }
            QLabel#statusGood { color:#00ff9d; font:10px Menlo,monospace; }
            QLabel#statusAccent { color:#ffb4bd; font:bold 10px Menlo,monospace; }
            QLabel#separator { color:#345045; }
            QSplitter::handle { background:#14211b; width:2px; }
            QScrollBar:vertical { background:#0b100e; width:10px; }
            QScrollBar::handle:vertical { background:#284838; border-radius:4px; min-height:25px; }
        """)

    def _install_shortcuts(self):
        shortcuts = [
            ("QShortcut", "Ctrl+L", self.focus_address),
            ("QShortcut", "Meta+L", self.focus_address),
            ("QShortcut", "Ctrl+R", self.reload_page),
            ("QShortcut", "Meta+R", self.reload_page),
            ("QShortcut", "Alt+Left", self.go_back),
            ("QShortcut", "Alt+Right", self.go_forward),
            ("QShortcut", "Meta+Shift+Backspace", self.reset_session),
        ]
        from PyQt6.QtGui import QShortcut
        self._shortcuts = []
        for _, sequence, callback in shortcuts:
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(callback)
            self._shortcuts.append(shortcut)

    def _new_profile_and_page(self):
        profile = QWebEngineProfile(self)  # unnamed constructor => off-the-record profile
        profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.MemoryHttpCache)
        profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies)

        # Use the actual bundled Chromium desktop UA, but omit the QtWebEngine token if present.
        ua = profile.httpUserAgent()
        ua = re.sub(r"\s*QtWebEngine/[^ ]+", "", ua)
        profile.setHttpUserAgent(ua)

        settings = profile.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.DnsPrefetchEnabled, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.AllowRunningInsecureContent, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.WebRTCPublicInterfacesOnly, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.HyperlinkAuditingEnabled, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.ScreenCaptureEnabled, False)
        if hasattr(QWebEngineSettings.WebAttribute, "ReadingFromCanvasEnabled"):
            settings.setAttribute(QWebEngineSettings.WebAttribute.ReadingFromCanvasEnabled, False)

        interceptor = RequestInterceptor(self.tracker_domains, self.security_domains, profile)
        interceptor.event.connect(self.on_request_event)
        interceptor.blocked.connect(self.on_request_blocked)
        profile.setUrlRequestInterceptor(interceptor)
        profile.downloadRequested.connect(self.on_download_requested)

        script = QWebEngineScript()
        script.setName("BlackHatPrivacyBaseline")
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        script.setRunsOnSubFrames(True)
        script.setSourceCode(r"""
        (() => {
          // Stable, common values reduce variation; no per-page random canvas noise is used.
          // Canvas randomization often increases uniqueness and can break legitimate sites.
          const define = (object, key, value) => {
            try { Object.defineProperty(object, key, { configurable: false, enumerable: true, get: () => value }); }
            catch (_) {}
          };
          try {
            define(Navigator.prototype, 'hardwareConcurrency', 4);
            define(Navigator.prototype, 'plugins', Object.freeze([]));
            define(Navigator.prototype, 'mimeTypes', Object.freeze([]));
          } catch (_) {}
        })();
        """)
        profile.scripts().insert(script)

        old_profile = getattr(self, "profile", None)
        old_page = getattr(self, "page", None)
        self.profile = profile
        self.interceptor = interceptor
        page = BrowserPage(profile, self, self.browser)
        self.page = page
        # Deny camera, microphone, location, notifications, and other page permissions.
        if hasattr(page, "permissionRequested"):
            page.permissionRequested.connect(lambda permission: permission.deny())
        elif hasattr(page, "featurePermissionRequested"):
            def deny_legacy_permission(origin, feature, p=page):
                p.setFeaturePermission(
                    origin, feature, QWebEnginePage.PermissionPolicy.PermissionDeniedByUser
                )
            page.featurePermissionRequested.connect(deny_legacy_permission)
        self.browser.setPage(page)

        if old_page is not None:
            old_page.deleteLater()
        if old_profile is not None:
            QTimer.singleShot(500, old_profile.deleteLater)

    def _show_home(self):
        self.address.clear()
        self.browser.setHtml(HOME_HTML, QUrl("about:blank"))
        self.log_event("BROWSER", "Opened local Black Hat start page")

    def show_message_page(self, title, message, detail=""):
        page_html = f"""<!doctype html><html><head><meta charset='utf-8'><style>
        body{{margin:0;background:#080c0b;color:#eaf4ef;font:16px -apple-system,sans-serif;display:grid;place-items:center;min-height:100vh}}
        main{{max-width:700px;margin:30px;padding:42px;border:1px solid #27533f;background:#101916;border-radius:18px}}
        h1{{color:#00ff9d;font-size:28px;letter-spacing:2px}}p{{color:#aec2b7;line-height:1.7}}small{{color:#61796c}}
        </style></head><body><main><h1>{html.escape(title)}</h1><p>{html.escape(message)}</p><small>{html.escape(detail)}</small></main></body></html>"""
        self.browser.setHtml(page_html, QUrl("about:blank"))

    def show_threat_page(self, host, reason):
        safe_host = html.escape(host or "unknown host")
        safe_reason = html.escape(reason)
        page_html = f"""<!doctype html><html><head><meta charset='utf-8'><style>
        body{{margin:0;background:radial-gradient(circle at 50% 40%,#320e14,#080809 65%);color:#fff;font:16px -apple-system,sans-serif;display:grid;place-items:center;min-height:100vh}}
        main{{max-width:760px;margin:24px;padding:42px;border:1px solid #a92e3e;background:#140d10;border-radius:18px;box-shadow:0 0 55px #d51c3626}}
        .tag{{color:#ff6579;font:11px Menlo,monospace;letter-spacing:3px}}h1{{font-size:34px;color:#ff526a;margin:15px 0}}p{{color:#dec7cb;line-height:1.65}}code{{color:#ffb7c0;background:#260f15;padding:5px 8px;border-radius:5px}}.line{{height:1px;background:#4e2029;margin:22px 0}}
        </style></head><body><main><div class='tag'>BLACK HAT // DEFENSIVE RESPONSE</div><h1>SECURITY WARNING: THREAT BLOCKED</h1><p>{safe_reason}</p><p>Host: <code>{safe_host}</code></p><div class='line'></div><p>The download was deleted or the host was added to your local denylist. Do not retry the file from another source unless you can independently verify it.</p></main></body></html>"""
        self.browser.setHtml(page_html, QUrl("about:blank"))
        self.log_event("SECURITY", f"Threat blocked: {host}")

    def focus_address(self):
        self.address.setFocus()
        self.address.selectAll()

    def navigate(self):
        raw = self.address.text().strip()
        if not raw:
            return
        if " " in raw or ("." not in raw and not raw.startswith(("http://", "https://"))):
            target = "https://www.google.com/search?q=" + quote_plus(raw)
        else:
            target = raw if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", raw) else "https://" + raw
        parsed = urlsplit(target)
        if parsed.scheme.lower() == "http":
            target = "https://" + target[len("http://"):]
            parsed = urlsplit(target)
        if parsed.scheme.lower() != "https":
            self.show_message_page("HTTPS ONLY", "Only HTTPS web addresses are permitted.", target)
            self.log_event("POLICY", f"Rejected non-HTTPS URL: {target}")
            return
        host = parsed.hostname or ""
        if host_matches(host, self.security_domains):
            self.show_threat_page(host, "This host is present in your local security denylist.")
            return
        if not self.tor_verified:
            self.show_message_page("TOR NOT VERIFIED", "Black Hat will not send web traffic until the configured proxy is confirmed as a Tor exit.", "Start Tor and wait for TOR: VERIFIED in the status bar.")
            return
        self.browser.setUrl(QUrl(target))
        self.log_event("NAVIGATION", target)

    def go_back(self):
        self.browser.back()

    def go_forward(self):
        self.browser.forward()

    def reload_page(self):
        self.browser.reload()

    def toggle_console(self):
        visible = self.console_panel.isVisible()
        self.console_panel.setVisible(not visible)
        self.console_toggle.setText("CONSOLE" if visible else "HIDE LOG")

    def on_url_changed(self, url):
        if url.scheme() == "https":
            self.address.setText(url.toString())
        elif url.scheme() in ("about", "data", "qrc"):
            self.address.clear()

    def on_load_finished(self, ok):
        self.log_event("BROWSER", "Page loaded" if ok else "Page load failed or was blocked")

    def on_title_changed(self, title):
        self.setWindowTitle(f"{title[:70]} — Black Hat" if title else "Black Hat — Private Browser")

    def log_event(self, source, message):
        timestamp = time.strftime("%H:%M:%S")
        safe_source = html.escape(str(source))
        safe_message = html.escape(str(message))
        self.console.append(f"<span style='color:#577568'>[{timestamp}]</span> <span style='color:#00ff9d'>{safe_source}</span>  {safe_message}")
        scrollbar = self.console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def on_request_event(self, host, kind):
        self.log_event(host, kind)

    def on_request_blocked(self, host, reason):
        self.blocked_count += 1
        self.blocked_label.setText(f"BLOCKED: {self.blocked_count}")
        self.log_event(host, f"BLOCKED · {reason}")

    def check_tor_status(self):
        now_online = tor_socks_available()
        if now_online != self.tor_online:
            self.tor_online = now_online
            if now_online:
                self.tor_verified = False
                self.tor_label.setText("TOR: VERIFYING")
                self.tor_label.setStyleSheet("color:#e9c46a;font: bold 10px Menlo,monospace")
                self.log_event("TOR", "SOCKS5 proxy reachable; verifying Tor exit before browsing")
                self.check_tor_ip()
            else:
                self.tor_verified = False
                self.tor_label.setText("TOR: OFFLINE")
                self.tor_label.setStyleSheet("color:#ff687b;font: bold 10px Menlo,monospace")
                self.ip_label.setText("EXIT IP: —")
                self.log_event("TOR", "SOCKS5 proxy not reachable; web navigation is disabled")
        elif now_online and not self.tor_verified and (self.ip_worker is None or not self.ip_worker.isRunning()):
            if not hasattr(self, "_last_ip_check") or time.time() - self._last_ip_check > 60:
                self.check_tor_ip()

    def check_tor_ip(self):
        if self.ip_worker is not None and self.ip_worker.isRunning():
            return
        self._last_ip_check = time.time()
        self.ip_worker = IpCheckWorker(self)
        self.ip_worker.completed.connect(self.on_ip_checked)
        self.ip_worker.start()

    def on_ip_checked(self, ip, message):
        self.ip_label.setText(f"EXIT IP: {ip}")
        self.tor_verified = (message == "Tor exit verified")
        self.log_event("TOR", message)
        if self.tor_verified:
            self.tor_label.setText("TOR: VERIFIED")
            self.tor_label.setStyleSheet("color:#00ff9d;font: bold 10px Menlo,monospace")
        else:
            self.tor_label.setText("TOR: UNVERIFIED")
            self.tor_label.setStyleSheet("color:#ffb35c;font: bold 10px Menlo,monospace")

    def refresh_filter_lists(self):
        if self.filter_worker is not None and self.filter_worker.isRunning():
            return
        self.filter_worker = FilterListWorker(self)
        self.filter_worker.completed.connect(self.on_filters_loaded)
        self.filter_worker.start()

    def on_filters_loaded(self, domains, message):
        self.tracker_domains.update(domains)
        if hasattr(self, "interceptor"):
            self.interceptor.update_domains(self.tracker_domains, self.security_domains)
        self.log_event("FILTERS", message)

    def reset_session(self):
        answer = QMessageBox.question(
            self, "Reset private session",
            "Clear this browser profile, replace it with a fresh in-memory profile, and request a new Tor circuit?",
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Reset,
            QMessageBox.StandardButton.Reset,
        )
        if answer != QMessageBox.StandardButton.Reset:
            return

        self.browser.stop()
        try:
            self.profile.cookieStore().deleteAllCookies()
            self.profile.clearHttpCache()
        except Exception:
            pass
        self._new_profile_and_page()
        self.blocked_count = 0
        self.blocked_label.setText("BLOCKED: 0")
        self.tor_verified = False
        self.tor_label.setText("TOR: VERIFYING")
        self.tor_label.setStyleSheet("color:#e9c46a;font: bold 10px Menlo,monospace")
        self._last_ip_check = 0
        self.log_event("SESSION", "Old off-the-record profile replaced; in-memory state cleared")
        self._show_home()
        if self.control_worker is None or not self.control_worker.isRunning():
            self.control_worker = TorControlWorker(self)
            self.control_worker.completed.connect(self.on_newnym_result)
            self.control_worker.start()
        else:
            self.log_event("TOR", "A circuit request is already running")

    def on_newnym_result(self, success, message):
        self.log_event("TOR", ("NEWNYM accepted · " if success else "NEWNYM not completed · ") + message)
        self._last_ip_check = 0
        QTimer.singleShot(4000, self.check_tor_ip)
        if not success:
            QMessageBox.information(self, "Tor circuit request", message + "\n\nThe browser session was still reset.")

    def on_download_requested(self, download):
        QUARANTINE_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            os.chmod(QUARANTINE_DIR, 0o700)
        except OSError:
            pass
        filename = f"{uuid.uuid4().hex[:8]}-{safe_filename(download.suggestedFileName())}"
        download.setDownloadDirectory(str(QUARANTINE_DIR))
        download.setDownloadFileName(filename)
        source_url = download.url().toString()
        path = str(QUARANTINE_DIR / filename)
        self.pending_sources[path] = source_url
        self.current_downloads.add(path)
        download.stateChanged.connect(lambda state, d=download, p=path: self.on_download_state_changed(d, p, state))
        download.accept()
        self.log_event("DOWNLOAD", f"Quarantined download started: {filename}")

    def on_download_state_changed(self, download, path, state):
        try:
            if state == QWebEngineDownloadRequest.DownloadState.DownloadCompleted:
                source_url = self.pending_sources.get(path, download.url().toString())
                self.log_event("DOWNLOAD", f"Download complete; hashing {Path(path).name}")
                api_key = os.environ.get("VT_API_KEY", "").strip()
                worker = FileScanWorker(path, source_url, api_key, self)
                worker.completed.connect(self.on_scan_completed)
                worker.finished.connect(lambda w=worker: self._discard_scan_worker(w))
                self.scan_workers.append(worker)
                worker.start()
            elif state in (
                QWebEngineDownloadRequest.DownloadState.DownloadInterrupted,
                QWebEngineDownloadRequest.DownloadState.DownloadCancelled,
            ):
                self.log_event("DOWNLOAD", f"Download did not complete: {Path(path).name}")
                self.current_downloads.discard(path)
        except Exception as exc:
            self.log_event("DOWNLOAD", f"Download-state handler error: {type(exc).__name__}")

    def _discard_scan_worker(self, worker):
        try:
            self.scan_workers.remove(worker)
        except ValueError:
            pass
        worker.deleteLater()

    def on_scan_completed(self, file_path, source_url, sha256, verdict, detail):
        host = urlsplit(source_url).hostname or ""
        name = Path(file_path).name
        self.log_event("MALWARE SCAN", f"{verdict.upper()} · {name} · SHA256 {sha256[:16]}… · {detail}")

        if verdict == "malicious":
            try:
                if Path(file_path).parent.resolve() == QUARANTINE_DIR.resolve() and os.path.isfile(file_path):
                    os.remove(file_path)
            except OSError as exc:
                self.log_event("SECURITY", f"Could not delete quarantined file: {type(exc).__name__}")
            if host:
                self.security_domains.add(host.lower())
                write_blocklist(self.security_domains)
                if hasattr(self, "interceptor"):
                    self.interceptor.update_domains(self.tracker_domains, self.security_domains)
            self.current_downloads.discard(file_path)
            self.show_threat_page(host, f"VirusTotal reports this downloaded file as malicious. {detail}")
            QMessageBox.warning(self, "Security Warning: Threat Blocked", f"The quarantined file was flagged and deleted.\n\nSHA-256: {sha256}\nSource host added to local blocklist: {host or 'unknown'}")
            return

        if verdict == "clean":
            choice = QMessageBox.question(
                self, "Scan complete — no detections",
                f"No malicious or suspicious detections were returned. This is not a guarantee the file is safe.\n\nSHA-256:\n{sha256}\n\nSave a copy outside quarantine?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel,
            )
            if choice == QMessageBox.StandardButton.Save:
                dest, _ = QFileDialog.getSaveFileName(self, "Save scanned download", str(Path.home() / safe_filename(name.split('-', 1)[-1])))
                if dest:
                    try:
                        shutil.copy2(file_path, dest)
                        os.remove(file_path)
                        self.log_event("DOWNLOAD", f"User saved file: {dest}")
                    except OSError as exc:
                        QMessageBox.warning(self, "Save failed", str(exc))
            self.current_downloads.discard(file_path)
            return

        # Unknown/review/error: keep the file in quarantine; never auto-open or release it.
        QMessageBox.information(
            self, "Download remains quarantined",
            f"The file was not cleared for release.\n\nStatus: {verdict.upper()}\n{detail}\n\nSHA-256:\n{sha256}\n\nFile remains in:\n{file_path}"
        )
        self.current_downloads.discard(file_path)

    def closeEvent(self, event):
        try:
            self.browser.stop()
            self.profile.cookieStore().deleteAllCookies()
            self.profile.clearHttpCache()
        except Exception:
            pass
        # Let finite-timeout worker tasks finish before Qt tears down their QThread objects.
        workers = [self.filter_worker, self.ip_worker, self.control_worker, *self.scan_workers]
        for worker in workers:
            if worker is not None and worker.isRunning():
                worker.wait()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("BlackHatOpenSource")
    app.setStyle("Fusion")
    window = BrowserWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
